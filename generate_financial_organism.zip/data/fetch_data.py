def fetch_data(): pass
