def latency(): return 0
