def encrypt(x): return x
