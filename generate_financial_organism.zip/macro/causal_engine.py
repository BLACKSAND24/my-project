class MacroCausalEngine: pass
