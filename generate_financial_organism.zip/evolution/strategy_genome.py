class StrategyGenome: pass
