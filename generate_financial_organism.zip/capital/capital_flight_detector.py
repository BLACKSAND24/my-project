class CapitalFlightDetector: pass
