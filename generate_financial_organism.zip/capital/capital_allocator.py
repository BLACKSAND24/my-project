class CapitalAllocator: pass
