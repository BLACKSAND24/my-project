def train(): pass
