class Strategy: pass
