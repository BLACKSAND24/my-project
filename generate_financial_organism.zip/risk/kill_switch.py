class KillSwitch:
    def __init__(self): self.active=True
    def trigger(self,r): self.active=False
