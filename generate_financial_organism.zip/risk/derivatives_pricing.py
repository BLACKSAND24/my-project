class BlackScholes: pass
