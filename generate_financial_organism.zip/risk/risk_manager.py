class RiskManager: pass
