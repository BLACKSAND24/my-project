class ConvexityEngine: pass
