class StopLossManager: pass
