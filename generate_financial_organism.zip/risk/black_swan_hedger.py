class BlackSwanHedger: pass
