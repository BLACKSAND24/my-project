class CrisisSimulator: pass
