def alert(msg): print(msg)
