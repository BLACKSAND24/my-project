# Operations Runbook

Emergency: Trigger Kill Switch
