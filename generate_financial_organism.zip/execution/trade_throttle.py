class TradeThrottle: pass
