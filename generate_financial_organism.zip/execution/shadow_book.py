class ShadowBook: pass
