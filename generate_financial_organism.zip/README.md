# Financial Organism

Run in PAPER mode only.
